
% RUNDEMO Illustrates the use of BFILTER2 and CARTOON.
%    This demo shows typical usage for the bilateral 
%    filter implemented by BFILTER2. The application
%    of bilateral filtering to image abstraction is
%    demonstrated by the CARTOON function.
%
% Douglas R. Lanman, Brown University, September 2006.
% dlanman@brown.edu, http://mesh.brown.edu/dlanman


% Load test images.
% Note: Must be double precision in the interval [0,1].
img1 = double(imread('gaosi.jpg'))/255;


% Set bilateral filter parameters.
w     = 5;       % bilateral filter half-width
sigma = [1.48 0.24
    ]; % bilateral filter standard deviations

% Apply bilateral filter to each image.
bflt_img1 = bfilter2(img1,w,sigma);


ref = double(imread('yuanshi.jpg'))/255;
REF = ref(:,:,1);
imshow(cat(2, ref,img1, bflt_img1, bflt_img1 -img1, bflt_img1-REF),[])
psnr = getPSNR(ref, bflt_img1)
ssim(ref,bflt_img1)


