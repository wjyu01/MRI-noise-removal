% Grayscale BM3D denoising demo file, based on Y. M??kinen, L. Azzari, A. Foi, 2019.
% Exact Transform-Domain Noise Variance for Collaborative Filtering of Stationary Correlated Noise.
% In IEEE International Conference on Image Processing (ICIP), pp. 185-189

% ---
% The location of the BM3D files -- this folder only contains demo data
addpath('bm3d');

% Experiment specifications   
imagename = 'gaosi.jpg';
image2name = 'yuanshi.jpg';

% Load noise-free image
y = im2double(imread(imagename));

% Call BM3D With the default settings.
y_est = BM3D(y, 0.1);

% To include refiltering:
%y_est = BM3D(z, PSD, 'refilter');

% For other settings, use BM3DProfile.
% profile = BM3DProfile(); % equivalent to profile = BM3DProfile('np');
% profile.gamma = 6;  % redefine value of gamma parameter
% y_est = BM3D(z, PSD, profile);

% Note: For white noise, you may instead of the PSD 
% also pass a standard deviation 
% y_est = BM3D(z, sqrt(noise_var));


%psnr = getPSNR(y, y_est)

% PSNR ignoring 16-pixel wide borders (as used in the paper), due to refiltering potentially leaving artifacts
% on the pixels near the boundary of the image when noise is not circulant
%psnr_cropped = getCroppedPSNR(y, y_est, [16, 16])

figure,
%subplot(1, 3, 1);
%imshow(y);
%title('y');
%subplot(1, 3, 3);
%imshow(y_est);
%title('y_{est}');
Y = y(:,:,1);
Y_EST = y_est(:,:,1);
ref = im2double(imread(image2name));
REF = ref(:,:,1);
imshow(cat(2, REF, Y, Y_EST,Y_EST-Y, Y_EST-REF),[])
%[PSNRCur, SSIMCur] = Cal_PSNRSSIM(im2uint8(REF),im2uint8(Y_EST),0,0);
%disp([num2str(PSNRCur,'%2.2f'),'dB','    ',num2str(SSIMCur,'%2.4f')])
psnr = getPSNR(ref, y_est)
ssim(ref, y_est)
